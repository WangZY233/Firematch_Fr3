#ifndef __UDP_NODE_H_
#define __UDP_NODE_H_

#include <ros/ros.h>
#include <std_msgs/Int64.h>
#include <std_msgs/String.h>
#include <mutex>
#endif