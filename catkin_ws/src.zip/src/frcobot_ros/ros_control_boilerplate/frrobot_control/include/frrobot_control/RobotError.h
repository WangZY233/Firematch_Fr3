#ifndef   ROBOTERROR_H_
#define   ROBOTERROR_H_

#define     ERR_SUCCESS       0

#endif
