# MoveIt Msgs

This package includes the ROS messages specific to MoveIt

## Travis - Continuous Integration

Kinetic | Melodic
------- | -------
[![Build Status](https://travis-ci.org/ros-planning/moveit_msgs.svg?branch=kinetic-devel)](https://travis-ci.org/ros-planning/moveit_msgs) | [![Build Status](https://travis-ci.org/ros-planning/moveit_msgs.svg?branch=melodic-devel)](https://travis-ci.org/ros-planning/moveit_msgs)
