编译前需要先执行以下命令：
sudo apt-get install libxmlrpcpp-dev
否则catkin_make会报错：/usr/bin/ld: 找不到 -lxmlrpcpp